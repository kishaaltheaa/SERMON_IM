<?php
$connect = new mysqli("localhost", "root", "", "todo_list");

if (isset($_POST['task'])) {
    $task = $connect->real_escape_string($_POST['task']);
    $connect->query("INSERT INTO tasks (task) VALUES ('$task')");
}

if (isset($_GET['delete'])) {
    $id = $connect->real_escape_string($_GET['delete']);
    $connect->query("DELETE FROM tasks WHERE id = $id");
}

if (isset($_GET['complete'])) {
    $id = $connect->real_escape_string($_GET['complete']);
    $connect->query("UPDATE tasks SET status = 1 WHERE id = $id");
}

$tasks = $connect->query("SELECT * FROM tasks");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Simple To-Do List</title>
    <link rel="stylesheet" href="style.css">  
</head>
<body>

<div class="container">
    <h2>My To-Do List</h2>

    <form method="POST">
        <input type="text" name="task" placeholder="Enter a task..." required>
        <button type="submit">Add</button>
    </form>

    <ul>
        <?php while($row = $tasks->fetch_assoc()): ?>
            <li class="<?= $row['status'] ? 'done' : '' ?>">
                <?= htmlspecialchars($row['task']) ?>
                <?php if (!$row['status']): ?>
                    <a href="?complete=<?= $row['id'] ?>">[Mark as done]</a>
                <?php endif; ?>
                <a href="?delete=<?= $row['id'] ?>">[Delete]</a>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

</body>
</html>
